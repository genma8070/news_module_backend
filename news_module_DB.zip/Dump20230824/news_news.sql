-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: news
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `news_id` int NOT NULL AUTO_INCREMENT,
  `main_category` int NOT NULL,
  `sub_category` int NOT NULL,
  `title` varchar(45) NOT NULL,
  `text` varchar(45) NOT NULL,
  `open` tinyint NOT NULL,
  `creat_date` date NOT NULL,
  `updata_date` date DEFAULT NULL,
  `open_date` date DEFAULT NULL,
  PRIMARY KEY (`news_id`),
  KEY `main_id_idx` (`main_category`),
  KEY `sub_id_idx` (`sub_category`),
  CONSTRAINT `main_id` FOREIGN KEY (`main_category`) REFERENCES `main_categorys` (`id`),
  CONSTRAINT `sub_id` FOREIGN KEY (`sub_category`) REFERENCES `sub_categorys` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,2,12,'12312312','哈哈哈哈哈哈哈哈哈哈',1,'2023-08-22','2023-08-23','2023-08-23'),(2,1,2,'sdfsdf','dsasda',1,'2023-08-22',NULL,'2023-08-22'),(3,3,9,'TYRTYHTYTRERHTG','FDHGFHGDFDSGFHG',1,'2023-08-23',NULL,'2023-08-23'),(4,1,4,'FNFFBCE','FDCNGFSGNHGFGF',1,'2023-08-23',NULL,'2023-08-23'),(5,1,3,'DASFDCVZX','CXVCX',1,'2023-08-23',NULL,'2023-08-23'),(6,1,1,'DSAFSDFDSAF','FASDFA',1,'2023-08-23',NULL,'2023-08-23'),(7,2,12,'AAAAAAA','AAAA',1,'2023-08-23',NULL,'2023-08-23'),(8,2,8,'FDSFDASF','SDAFSDFSD',1,'2023-08-23',NULL,'2023-08-23'),(10,2,5,'12312312312','3123',1,'2023-08-23',NULL,'2023-08-23'),(11,2,6,'3321','dsfddsf',1,'2023-08-23',NULL,'2023-08-23'),(12,2,7,'3321ffffffff','dsfddsf',1,'2023-08-23',NULL,'2023-08-23'),(13,3,9,'衝鋒旋風龍捲風','哭阿',1,'2023-08-23',NULL,'2023-08-23'),(14,3,11,'霹靂卡霹靂啪啦波波莉娜貝貝魯波','喔喔喔喔喔喔喔喔',1,'2023-08-23',NULL,'2023-08-23'),(15,1,1,'scxvcx','vcxvxc',1,'2023-08-24',NULL,'2023-08-24'),(16,1,1,'scxvcx','vcxvxc',1,'2023-08-21',NULL,'2023-08-21'),(17,1,1,'scxvcx','vcxvxc',1,'2023-08-24',NULL,'2023-08-24'),(18,1,1,'scxvcx','vcxvxc',1,'2023-08-24',NULL,'2023-08-24'),(19,2,5,'12312312312312','123',1,'2023-08-24','2023-08-24','2023-08-24'),(20,1,3,'12312312312312','123',0,'2023-08-10',NULL,'2023-08-10'),(21,1,3,'12312312312312','123',1,'2023-08-24',NULL,'2023-08-24'),(22,1,3,'12312312312312','123',1,'2023-08-24',NULL,'2023-08-24'),(23,1,3,'69696969','123',1,'2023-08-24',NULL,'2023-08-24');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-24 16:34:05
